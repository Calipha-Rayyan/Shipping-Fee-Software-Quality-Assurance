# Assignment 1 starter kit - ShippingFee

```
starter_kit/
  README.md                     this file
  python/                       PyUnit side (one group member)
    shipping_ref.py             the program under test (correct version, Algorithm 1)
    faults/f01.py ... f10.py    ten faulty versions of the program
    target.py                   picks which version the tests run against (do not edit)
    tests/test_nc.py ...        one skeleton per criterion: nc, ec, pc, cc, cacc, racc, extra
    run_matrix.py               fault-detection matrix for all your suites
    tools/predcheck.py          predicate coverage helper (PC, CC, GACC, CACC, RACC)
    requirements.txt, pyproject.toml
  java/                         JUnit side (the other group member)
    src/main/java/shipping/     ShippingRef.java, ShippingF01..F10.java, Target.java
    src/test/java/shipping/     one skeleton per criterion + RunMatrix.java
    tools/bytecode_cfg.py       CFG of a compiled Java method (javap + Graphviz)
    run.sh                      compile + fault-detection matrix
    pom.xml                     optional: Maven build with JaCoCo and PIT
```

The Python and Java programs implement exactly the same specification and contain exactly the
same ten seeded faults. Your PyUnit and JUnit suites should therefore give identical matrices.
If they do not, one of the two suites (or one implementation) has a bug: find it.

## 0. One-time setup

* Python 3.10+ and a JDK 11+ (21 is fine). Install Graphviz (`dot` must be on your PATH):
  Linux `sudo apt install graphviz`, macOS `brew install graphviz`, Windows https://graphviz.org/download/
* Python member:
  ```
  cd python
  python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
  pip install -r requirements.txt
  ```
* Java member: download two jars from Maven Central into `java/lib/`
  `junit-4.13.2.jar` and `hamcrest-core-1.3.jar` (https://junit.org/junit4/ links to both),
  or use the Maven route in section 4.

## 1. Python (PyUnit) quick start - run everything from `python/`

| Task | Command |
|---|---|
| run one suite on the correct program | `python -m unittest tests.test_nc -v` |
| run one suite on a faulty version | `TARGET=f03 python -m unittest tests.test_nc -v` (Windows PowerShell: `$env:TARGET="f03"; python -m unittest tests.test_nc -v`) |
| fault-detection matrix | `python run_matrix.py` (`--details` shows which test kills which fault) |
| CFG of the program (Part A) | `py2cfg shipping_ref.py --outfile shipping_cfg --format png` (if it tries to open an image viewer and complains, ignore it, the file is written) |
| statement + branch coverage of a suite | `coverage run --branch --source=. -m unittest tests.test_racc` then `coverage report -m --include=shipping_ref.py` (add `coverage html` for a report) |
| MC/DC requirements of your suite | `python -m pymcdc --unittest tests/test_racc.py shipping_ref.py` |
| mutation testing | edit the test file named in `pyproject.toml`, then `mutmut run` and `mutmut results` (delete the `mutants/` folder when you switch suites) |
| logic requirements of one predicate | `python tools/predcheck.py gen "express && (!member \|\| weight > 5)"` |
| check your tests against one predicate | `python tools/predcheck.py check "member && fee >= 250" my_d6.csv` |

`predcheck check` reads a CSV whose header names the variables of the predicate, one row per test.
Derived variables such as `fee` must be supplied as a column: working out its value is part of
making a test executable.

Note on `py2cfg`: on some versions the command-line wrapper needs `--outfile`. From Python:
```python
from py2cfg import CFGBuilder
cfg = CFGBuilder().build_from_file('shipping_ref', 'shipping_ref.py')
cfg.functioncfgs['shipping_fee'].build_visual('shipping_cfg', 'png', show=False)
```

## 2. Java (JUnit 4) quick start - run everything from `java/`

| Task | Command |
|---|---|
| compile + matrix for all suites | `./run.sh` (Windows: use the equivalent `javac`/`java` lines from `run.sh`, with `;` instead of `:` in classpaths) |
| matrix with failing test names | `./run.sh --details` |
| one suite on a chosen version | `java -Dtarget=f03 -cp "out/classes:out/test:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar" org.junit.runner.JUnitCore shipping.NodeCoverageTest` |
| CFG of the compiled method | `python tools/bytecode_cfg.py out/classes shipping.ShippingRef fee > fee.dot && dot -Tpng fee.dot -o fee.png` |

## 3. Java coverage and mutation tools (command-line route)

JaCoCo: download the release zip from https://www.jacoco.org/jacoco/ and copy `lib/jacocoagent.jar`
and `lib/jacococli.jar` into `java/lib/`.
```
java -javaagent:lib/jacocoagent.jar=destfile=out/jacoco.exec -Dtarget=ref \
     -cp "out/classes:out/test:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar" \
     org.junit.runner.JUnitCore shipping.RestrictedActiveClauseCoverageTest
java -jar lib/jacococli.jar report out/jacoco.exec --classfiles out/classes/shipping/ShippingRef.class \
     --sourcefiles src/main/java --html out/jacoco-report
```
Open `out/jacoco-report/index.html`, go to `ShippingRef.fee`, and look at the diamonds in the margin
and at the "Missed Branches" counters.

## 4. Maven route (optional, runs JaCoCo and PIT for you)

`pom.xml` declares JUnit 4, JaCoCo and PIT. Check https://www.jacoco.org and https://pitest.org for
newer plugin versions and update the version numbers in the pom if your JDK is newer than 21.
```
mvn -Dtarget=ref -Dtest=NodeCoverageTest test                 # JaCoCo report in target/site/jacoco/
mvn test-compile org.pitest:pitest-maven:mutationCoverage \
    -DtargetClasses=shipping.ShippingRef \
    -DtargetTests=shipping.RestrictedActiveClauseCoverageTest   # PIT report in target/pit-reports/
```
Change `-DtargetTests` to judge a different suite.

## 5. Rules of the kit

* Always call `fee(...)` from `target.py` (Python) or `Target.fee(...)` (Java). Never call the program files directly.
* Expected values come from the SPECIFICATION, never from running the program.
* Do not open the `faults/` folder or the `ShippingF*.java` files while you are designing your suites
  (Parts A and B). Reading the faults before you have designed your tests defeats the experiment.
